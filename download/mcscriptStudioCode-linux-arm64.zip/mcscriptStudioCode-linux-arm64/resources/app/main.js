require("./client.js"); // Start client
