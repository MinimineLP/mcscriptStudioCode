# MCScript Base Plugin for MCScriptStudioCode
[MCScriptStudioCode](https://github.com/miniminelp/mcscriptStudioCode)
## Information
This is a plugin for MCScriptStudioCode. It makes [MCScript](https://github.com/stevertus/mcscript) running with the editor

## MCScriptStudioCode
MCScriptStudioCode is a editor wit Synthax-Highlighting like Notepad++ or Atom. This Editor is developed and optimized for editing mcfunction's and especially [MCScript](https://github.com/stevertus/mcscript).

## Authors
 - **Minimine** - *Initial work* - [Minimine](https://github.com/MinimineLP)

## License
This plugin for MCScriptStudioCode is Licensed under the [MIT License](https://github.com/MinimineLP/mcscriptStudioCode/blob/master/plugins/mcscript_base/LICENSE).
<br/>
[MCScriptStudioCode's License](https://github.com/MinimineLP/mcscriptStudioCode/blob/master/LICENSE) | [MCScript Base's License](https://github.com/MinimineLP/mcscriptStudioCode/blob/master/plugins/mcscript_base/LICENSE)
