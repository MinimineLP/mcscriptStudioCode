"use strict";exports.__esModule=!0,exports.default=editor,module.exports={editor:editor,Editor:Editor,createEditor:createEditor},module.exports.default=editor;
//# sourceMappingURL=Editor.js.map
