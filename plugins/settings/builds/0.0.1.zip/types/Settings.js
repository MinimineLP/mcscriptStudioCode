"use strict";exports.__esModule=!0,module.exports={SettingsAPI:SettingsAPI,settingsapi:settingsapi};
//# sourceMappingURL=Settings.js.map
