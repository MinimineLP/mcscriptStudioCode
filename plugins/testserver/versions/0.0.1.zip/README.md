# Testserver Plugin for MCScriptStudioCode
[MCScriptStudioCode](https://github.com/miniminelp/mcscriptStudioCode)
## Information
This is a plugin for MCScriptStudioCode. It adds a fully functional minecraft server to the program. You **HAVE TO** tell the plugin in the configuration file, where your Java command is located and where the server jar is located.

## MCScriptStudioCode
MCScriptStudioCode is a editor wit Synthax-Highlighting like Notepad++ or Atom. This Editor is developed and optimized for editing mcfunction's and especially [MCScript](https://github.com/stevertus/mcscript).

## Authors
 - **Minimine** - *Initial work* - [Minimine](https://github.com/MinimineLP)

## License
This Plugin for MCScriptStudioCode are Licensed under the [MIT License](https://github.com/MinimineLP/mcscriptStudioCode/blob/master/plugins/Testserver/LICENSE).
<br/>
[MCScriptStudioCode's License](https://github.com/MinimineLP/mcscriptStudioCode/blob/master/LICENSE) | [Testserver's License](https://github.com/MinimineLP/mcscriptStudioCode/blob/master/plugins/Testserver/LICENSE)
