"use strict";exports.__esModule=!0,module.exports={ShortcutbarAPI:ShortcutbarAPI};
//# sourceMappingURL=Shortcutbar.js.map
